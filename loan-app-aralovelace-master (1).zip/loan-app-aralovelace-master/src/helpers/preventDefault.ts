function preventDefault(e) {
  e.preventDefault();
  return e;
}

export { preventDefault };
